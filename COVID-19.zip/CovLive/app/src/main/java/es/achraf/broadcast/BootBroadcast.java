package es.achraf.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import es.achraf.service.ServiceLocation;

public class BootBroadcast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.startService(new Intent(context, ServiceLocation.class));
    }

}
