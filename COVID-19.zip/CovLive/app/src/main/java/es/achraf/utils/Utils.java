package es.achraf.utils;

import android.provider.ContactsContract;

public class Utils {

    public final static String PATH_PRIVACY_POLICY = "file:///android_asset/politicaprivacidad.html";
    public final static String IS_ACCEPT = "polity";
    public final static String[] FIELDS = new String[]{
            ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.Contacts.PHOTO_URI,
            ContactsContract.Contacts.HAS_PHONE_NUMBER};
    public final static String FILTER = ContactsContract.Data.MIMETYPE + "='" + ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE + "' AND "
            + ContactsContract.CommonDataKinds.Phone.NUMBER + " IS NOT NULL";
    public final static String SORT_ORDER = ContactsContract.Contacts.DISPLAY_NAME
            + " COLLATE LOCALIZED ASC";
    public static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 1000;
    public static final int ACCESS_COARSE_PERMISSION = 1010;
    public static final int ACCESS_FINE_PERMISSION = 1011;
    public static final int REQUEST_CHECK_SETTINGS = 1;
    public static final String URL_COVID_COMUNNITY = "https://covid19.secuoyas.io/api/v1/es/ccaa?ultimodia=true";

    public static int CONT = 0;

}
