package es.achraf.fragments;

import android.content.*;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.switchmaterial.SwitchMaterial;
import es.achraf.R;
import es.achraf.service.ServiceLocation;
import es.achraf.utils.Utils;

import java.util.Objects;

public class DistanceFragment extends Fragment {

    private SwitchMaterial switch_distancia;
    //private LocationManager manager;

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.distance_fragment, container, false);
        switch_distancia = v.findViewById(R.id.switch_distancia);
        //manager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

        //flpc = LocationServices.getFusedLocationProviderClient(getContext());

        SharedPreferences preferences = Objects.requireNonNull(getActivity()).getPreferences(Context.MODE_PRIVATE);
        String res = preferences.getString("distance", "");

        if (res.equalsIgnoreCase("on")) {
            switch_distancia.setChecked(true);
            switch_distancia.setText("Activado");
        } else {
            switch_distancia.setChecked(false);
            switch_distancia.setText("Desactivado");
        }


        switch_distancia.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if (switch_distancia.isChecked()) {
                    MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(Objects.requireNonNull(getActivity()))
                            .setTitle("Distancia de seguridad ACTIVADA")
                            .setMessage("Al aceptar, la aplicación le avisará mediante vibraciones cuando se sitúe a menos de 2 metros de distancia de otro usuario. Para que funcione NO debe apagar el GPS")
                            .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    openDialog();
                                    saveStatusSearchDistance("on");
                                    switch_distancia.setText("Activado");
                                    getActivity().startService(new Intent(getActivity(), ServiceLocation.class));
                                }
                            }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    switch_distancia.setText("Desactivado");
                                    switch_distancia.setChecked(false);
                                    Intent intentService = new Intent(getActivity(), ServiceLocation.class);
                                    getActivity().stopService(intentService);
                                }
                            });
                    dialog.show();
                } else {
                    saveStatusSearchDistance("off");
                    switch_distancia.setText("Desactivado");
                    Intent intentService = new Intent(getActivity(), ServiceLocation.class);
                    Objects.requireNonNull(getActivity()).stopService(intentService);
                }
            }

        });

        return v;
    }

    private void saveStatusSearchDistance(String status) {//será on o off
        SharedPreferences preferences = Objects.requireNonNull(getActivity()).getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("distance", status);
        editor.apply();
    }


    private void openDialog() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(30 * 1000);
        mLocationRequest.setFastestInterval(5 * 1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest);

        Task<LocationSettingsResponse> task = LocationServices.getSettingsClient(Objects.requireNonNull(getActivity())).checkLocationSettings(builder.build());

        task.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(@NonNull Task<LocationSettingsResponse> task) {
                try {
                    LocationSettingsResponse response = task.getResult(ApiException.class);

                } catch (ApiException exception) {
                    switch (exception.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:

                            try {
                                ResolvableApiException resolvable = (ResolvableApiException) exception;
                                resolvable.startResolutionForResult(Objects.requireNonNull(getActivity()), Utils.REQUEST_CHECK_SETTINGS);
                            } catch (IntentSender.SendIntentException | ClassCastException e) {
                                e.printStackTrace();
                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            //aquí creo que iría el código para inicializar
                            Toast.makeText(Objects.requireNonNull(getActivity()).getApplicationContext(), "hola", Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }
        });
    }



}
