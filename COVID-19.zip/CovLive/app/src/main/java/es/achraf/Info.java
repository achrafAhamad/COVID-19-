package es.achraf;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import es.achraf.utils.Utils;

public class Info extends AppCompatActivity implements View.OnClickListener {

    private WebView webView;
    private CheckBox chkEnabledAccept;
    private Button btnAcceptPolicy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);


        this.webView = findViewById(R.id.webview);
        this.chkEnabledAccept = findViewById(R.id.chkEnabledAccept);
        this.btnAcceptPolicy = findViewById(R.id.btnAcceptPolicy);

        this.chkEnabledAccept.setOnClickListener(this);
        this.btnAcceptPolicy.setOnClickListener(this);

        this.webView.loadUrl(Utils.PATH_PRIVACY_POLICY);
        this.webView.setWebViewClient(new WebViewClient());


        //Comprobar la politica de privacidad si está aceptada o no.
        SharedPreferences preferences = getSharedPreferences(Utils.IS_ACCEPT, Context.MODE_PRIVATE);

        int value = preferences.getInt("value", 0);
        if (value != 0) {
            startActivity(new Intent(Info.this, Login.class));
            finish();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

    }


    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.chkEnabledAccept:
                if (chkEnabledAccept.isChecked())
                    this.btnAcceptPolicy.setEnabled(true);
                else
                    this.btnAcceptPolicy.setEnabled(false);
                break;

            case R.id.btnAcceptPolicy:
                SharedPreferences.Editor editor = getSharedPreferences(Utils.IS_ACCEPT, MODE_PRIVATE).edit();

                //1 true y !=1 es false
                editor.putInt("value", 1);
                editor.apply();
                startActivity(new Intent(Info.this, Login.class));
                finish();
                break;
        }
    }
}
