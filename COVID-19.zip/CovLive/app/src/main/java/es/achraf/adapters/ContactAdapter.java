package es.achraf.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import es.achraf.R;
import es.achraf.model.Contact;

import java.util.ArrayList;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private final ArrayList<Contact> contacts;
    private final Context context;

    public ContactAdapter(ArrayList<Contact> contacts, Context context) {
        this.contacts = contacts;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_contact, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txt_name.setText(contacts.get(position).getName());
        holder.txt_phone.setText(contacts.get(position).getPhone());
        if (contacts.get(position).getImg() != null) {
            Uri uri = Uri.parse(contacts.get(position).getImg());
            holder.img_contact.setImageURI(uri);
        } else
            holder.img_contact.setImageDrawable(context.getDrawable(R.drawable.logo_foreground));
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_name;
        public TextView txt_phone;
        public ImageView img_contact;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            this.txt_name = itemView.findViewById(R.id.txt_name);
            this.txt_phone = itemView.findViewById(R.id.txt_number);
            this.img_contact = itemView.findViewById(R.id.img_contact);
        }

    }
}

