package es.achraf;

import android.Manifest;
import android.app.ActivityManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import es.achraf.fragments.DistanceFragment;
import es.achraf.fragments.HomeFragment;
import es.achraf.fragments.MapFragment;
import es.achraf.fragments.NewsFragment;
import es.achraf.service.ServiceLocation;
import es.achraf.utils.Utils;

public class Home extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        if (!isOnline(Home.this)) {

            AlertDialog alertDialog = new AlertDialog.Builder(this).create();

            alertDialog.setTitle("Conexión");
            alertDialog.setMessage("No dispone de conexión a internet.\nPor favor vuelva a intentarlo cuando tenga conexión a internet.");
            alertDialog.setIcon(R.drawable.ic_connection);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });

            alertDialog.show();
        } else {

            SharedPreferences preferences = getPreferences(MODE_PRIVATE);
            String res = preferences.getString("distance", "");
            if (res.equalsIgnoreCase("on")) {
                LocationManager locationManager =
                        (LocationManager) Home.this.getSystemService(Context.LOCATION_SERVICE);
                if (permission()) {
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        openDialog();
                    }
                }
                if (!isMyServiceRunning(ServiceLocation.class)) {
                    startService(new Intent(this, ServiceLocation.class));
                }
            }

            BottomNavigationView bottom_navigation = findViewById(R.id.bottom_navigation);
            bottom_navigation.setOnNavigationItemSelectedListener(this);
            Fragment fragment = new HomeFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager
                    .beginTransaction()
                    .setCustomAnimations(R.anim.entrada_izquierda, R.anim.entrada_derecha)
                    .replace(R.id.container, fragment).commit();

        }
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private boolean permission() {
        if (ActivityCompat.checkSelfPermission(Home.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(Home.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.checkSelfPermission(Home.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(Home.this,
                        Manifest.permission.ACCESS_COARSE_LOCATION)) {

                } else {
                    ActivityCompat.requestPermissions(Home.this, new String[]{
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                            },
                            Utils.ACCESS_COARSE_PERMISSION);
                }

            }
            if (ActivityCompat.checkSelfPermission(Home.this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(Home.this,
                        Manifest.permission.ACCESS_FINE_LOCATION)) {

                } else {
                    ActivityCompat.requestPermissions(Home.this, new String[]{
                                    Manifest.permission.ACCESS_FINE_LOCATION
                            },
                            Utils.ACCESS_FINE_PERMISSION);
                }
            }

            return false;
        } else {
            return true;
        }
    }

    public static boolean isOnline(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        FragmentManager fragmentManager = getSupportFragmentManager();
        switch (item.getItemId()) {
            case R.id.page_home:
                fragment = new HomeFragment();
                this.setTitle("Datos de COVID-19");
                break;

            case R.id.page_card:
                fragment = new DistanceFragment();
                this.setTitle("Distancia de seguridad");
                break;

            case R.id.page_contacts:
                fragment = new NewsFragment();
                this.setTitle("Noticias de última hora COVID-19");
                break;

            case R.id.page_map:
                fragment = new MapFragment();
                this.setTitle("Datos de las comunidades de España");
                break;
        }

        if (fragment != null) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.container, fragment);
            transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            transaction.setCustomAnimations(R.anim.entrada_izquierda, R.anim.entrada_derecha);
            transaction.commit();
            transaction.show(fragment);

        }
        return true;
    }

    private void openDialog() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(30 * 1000);
        mLocationRequest.setFastestInterval(5 * 1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest);

        Task<LocationSettingsResponse> task = LocationServices.getSettingsClient(Home.this).checkLocationSettings(builder.build());

        task.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(Task<LocationSettingsResponse> task) {
                try {
                    LocationSettingsResponse response = task.getResult(ApiException.class);
                } catch (ApiException exception) {
                    switch (exception.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:

                            try {
                                ResolvableApiException resolvable = (ResolvableApiException) exception;
                                resolvable.startResolutionForResult(Home.this, Utils.REQUEST_CHECK_SETTINGS);
                            } catch (IntentSender.SendIntentException e) {
                                e.printStackTrace();
                            } catch (ClassCastException e) {
                                e.printStackTrace();
                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            //aquí creo que iría el código para inicializar
                            break;
                    }
                }
            }
        });
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull
            String[] permissions, @NonNull int[] grantResults) {
    }


}
