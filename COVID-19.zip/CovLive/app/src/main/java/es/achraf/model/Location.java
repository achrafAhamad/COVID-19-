package es.achraf.model;

public class Location {

    private String zipcode;
    private String lat;
    private String lng;

    public Location(String zipcode, String lat, String lng) {
        this.zipcode = zipcode;
        this.lat = lat;
        this.lng = lng;
    }

    public Location() {

    }


    public String getLat() {
        return lat;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getLng() {
        return lng;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    @Override
    public String toString() {
        return "Location{" +
                "zipcode='" + zipcode + '\'' +
                ", lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                '}';
    }
}
