package es.achraf.model;

public class CommunityData {

    private String name;
    private String total_confirmed;
    private String total_death;
    private String new_confirmed;
    private String new_death;


    public CommunityData(String name, String total_confirmed, String total_death, String new_confirmed, String new_death) {
        this.name = name;
        this.total_confirmed = total_confirmed;
        this.total_death = total_death;
        this.new_confirmed = new_confirmed;
        this.new_death = new_death;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTotal_confirmed() {
        return total_confirmed;
    }

    public void setTotal_confirmed(String total_confirmed) {
        this.total_confirmed = total_confirmed;
    }

    public String getTotal_death() {
        return total_death;
    }

    public void setTotal_death(String total_death) {
        this.total_death = total_death;
    }

    public String getNew_confirmed() {
        return new_confirmed;
    }

    public void setNew_confirmed(String new_confirmed) {
        this.new_confirmed = new_confirmed;
    }

    public String getNew_death() {
        return new_death;
    }

    public void setNew_death(String new_death) {
        this.new_death = new_death;
    }

    @Override
    public String toString() {
        return "Community{" +
                "name='" + name + '\'' +
                ", total_confirmed='" + total_confirmed + '\'' +
                ", total_death='" + total_death + '\'' +
                ", new_confirmed='" + new_confirmed + '\'' +
                ", new_death='" + new_death + '\'' +
                '}';
    }
}
