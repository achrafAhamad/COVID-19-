package es.achraf.model;

public class ZipCode {

    private String zipCode;
    private String municipality;
    private String community;
    private String country;
    private String address;
    private String latitude;
    private String longitude;

    public ZipCode(String zipCode, String municipality, String community, String country, String address) {
        this.zipCode = zipCode;
        this.municipality = municipality;
        this.community = community;
        this.country = country;
        this.address = address;
    }

    public ZipCode(String zipCode, String latitude, String longitude, String address) {
        this.zipCode = zipCode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.address = address;
    }

    public ZipCode() {

    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getAddress() {
        return address;
    }

    public String getCommunity() {
        return community;
    }

    public String getCountry() {
        return country;
    }

    public String getMunicipality() {
        return municipality;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCommunity(String community) {
        this.community = community;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "ZipCode{" +
                "zipCode='" + zipCode + '\'' +
                ", municipality='" + municipality + '\'' +
                ", community='" + community + '\'' +
                ", country='" + country + '\'' +
                ", address='" + address + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                '}';
    }
}
