package es.achraf.fragments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import com.google.android.material.appbar.MaterialToolbar;
import es.achraf.Home;
import es.achraf.R;

import java.util.Objects;

public class NewsFragment extends Fragment {

    private WebView news_webview;
    private MaterialToolbar appBar;
    private String URL = "https://www.mscbs.gob.es/en/profesionales/saludPublica/ccayes/alertasActual/nCov-China/home.htm";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.news_fragment, container, false);
        this.news_webview = v.findViewById(R.id.news_webview);
        this.appBar = v.findViewById(R.id.topAppBar);

        if (Home.isOnline(Objects.requireNonNull(getContext()))) {
            this.news_webview.loadUrl(URL);
            this.news_webview.setWebViewClient(new WebViewClient());
            this.news_webview.getSettings().setJavaScriptEnabled(true);
            this.news_webview.clearCache(false);
            this.news_webview.getSettings().setDomStorageEnabled(true);
            this.news_webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        } else {

            AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();

            alertDialog.setTitle("Conexión");
            alertDialog.setMessage("No dispone de conexión a internet.\nPor favor vuelva a intentarlo cuando tenga conexión a internet.");
            alertDialog.setIcon(R.drawable.ic_connection);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    getActivity().finish();
                }
            });

            alertDialog.show();
        }


        this.appBar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.arrow_left:
                        if (news_webview.canGoBack())
                            news_webview.goBack();
                        break;
                    case R.id.arrow_home:
                        news_webview.loadUrl(URL);
                        news_webview.clearHistory();
                        break;

                    case R.id.arrow_right:
                        if (news_webview.canGoForward())
                            news_webview.goForward();
                        break;
                }
                return true;
            }
        });

        return v;
    }

}
