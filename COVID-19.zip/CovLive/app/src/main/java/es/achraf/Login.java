package es.achraf;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.afollestad.materialdialogs.MaterialDialog;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.*;

import java.util.concurrent.TimeUnit;

public class Login extends AppCompatActivity {

    private TextInputEditText txt_phone;
    private MaterialButton btn_sendSMS;
    private MaterialDialog dialog;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private PhoneAuthProvider provider;
    private String mVerificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        this.txt_phone = findViewById(R.id.txt_phone);
        this.btn_sendSMS = findViewById(R.id.btn_sendSMS);

        this.provider = PhoneAuthProvider.getInstance();

        this.mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null) {
            startActivity(new Intent(Login.this, Home.class));
            finish();
        }

        this.mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    Log.d("Login", "onAuthStateChanged:signed_in:" + user.getUid());
                }
            }
        };


        this.btn_sendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog = new MaterialDialog.Builder(Login.this)
                        .icon(getDrawable(R.drawable.logo_foreground))
                        .title("SMS de verificación")
                        .content("Cargando...")
                        .progress(true, 150)
                        .show();
                sendSMS(dialog);
            }
        });

    }


    //método para enviar el SMS con el código de verificación [De momento solo para teléfonos españoles]
    private void sendSMS(final MaterialDialog dialog) {
        String code_spain = "+34";
        String phone = code_spain.concat(txt_phone.getText().toString());
        if (!TextUtils.isEmpty(phone)) {

            this.provider.verifyPhoneNumber(phone, 60, TimeUnit.SECONDS, this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override
                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                    dialog.dismiss();
                    signInWithCodeSMS(phoneAuthCredential);
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    if (e instanceof FirebaseAuthInvalidCredentialsException)
                        Snackbar.make(getWindow().getDecorView(), "El télefono introducido es incorrecto.", Snackbar.LENGTH_SHORT).show();
                    else if ((e instanceof FirebaseTooManyRequestsException))
                        Snackbar.make(getWindow().getDecorView(), "Se ha sobrepasado el limite de envío de SMS.", Snackbar.LENGTH_SHORT).show();
                    dialog.dismiss();
                }

                @Override
                public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                    super.onCodeSent(verificationId, forceResendingToken);
                    mVerificationId = verificationId;

                    MaterialAlertDialogBuilder dialgo = new MaterialAlertDialogBuilder(Login.this)
                            .setTitle(txt_phone.getText().toString())
                            .setMessage("¿Esta seguro de que ha introducido su numero de teléfono correctamente?\nTendrá que verificarlo mediante un código SMS.")
                            .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = new Intent(Login.this, Verify.class);
                                    intent.putExtra("verificationId", mVerificationId);
                                    intent.putExtra("phone_back", txt_phone.getText().toString());
                                    startActivity(intent);
                                    finish();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            });
                    dialgo.show();
                    dialog.dismiss();
                }
            });
        } else {
            Toast.makeText(this, "Debe introducir un número de teléfono válido", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        }

    }

    private void signInWithCodeSMS(PhoneAuthCredential phoneAuthCredential) {
        mAuth.signInWithCredential(phoneAuthCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    dialog.dismiss();
                    startActivity(new Intent(Login.this, Home.class));
                    finish();
                } else {
                    Toast.makeText(Login.this, "ERROR-line(140): " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Toast.makeText(Login.this, "ERROR-line(149): " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        this.mAuth.addAuthStateListener(this.mAuthListener);
    }

}
