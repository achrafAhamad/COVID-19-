package es.achraf.fragments;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;
import com.jaredrummler.materialspinner.MaterialSpinner;
import es.achraf.Home;
import es.achraf.R;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class HomeFragment extends Fragment {

    private MaterialTextView txt_number_cases_confirmed;
    private MaterialTextView txt_number_cases_death;
    private MaterialTextView txt_number_cases_confirmed_new;
    private MaterialTextView txt_number_death_new;

    private MaterialTextView txt_date_updated_death;
    private MaterialTextView txt_date_updated_confirmed;
    private MaterialTextView txt_date_updated_deat_new;
    private MaterialTextView txt_date_updated_confirmed_new;

    private MaterialCardView card_confirmed;
    private MaterialCardView card_death;
    private MaterialCardView card_death_new;
    private MaterialCardView card_confirmed_new;

    private MaterialSpinner spinner_country;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.home_fragment, container, false);

        txt_number_cases_confirmed = v.findViewById(R.id.txt_number_cases_confirmed);
        txt_number_cases_death = v.findViewById(R.id.txt_number_cases_death);
        txt_number_cases_confirmed_new = v.findViewById(R.id.txt_number_cases_new);
        txt_number_death_new = v.findViewById(R.id.txt_number_cases_death_new);

        txt_date_updated_confirmed = v.findViewById(R.id.txt_date_updated_confirmed);
        txt_date_updated_death = v.findViewById(R.id.txt_date_updated_death);
        txt_date_updated_confirmed_new = v.findViewById(R.id.txt_date_updated_confirmed_new);
        txt_date_updated_deat_new = v.findViewById(R.id.txt_date_updated_death_new);

        card_confirmed = v.findViewById(R.id.card_confirmed);
        card_death = v.findViewById(R.id.card_death);
        card_confirmed_new = v.findViewById(R.id.card_confirmed_new);
        card_death_new = v.findViewById(R.id.card_death_new);

        spinner_country = v.findViewById(R.id.spinner_country);


        ArrayAdapter aa = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_item, getListCountries());
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_country.setAdapter(aa);


        spinner_country.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                if (Home.isOnline(getContext()))
                    showCountryInfo(item.toString());
                else {

                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();

                    alertDialog.setTitle("Conexión");
                    alertDialog.setMessage("No dispone de conexión a internet.\nPor favor vuelva a intentarlo cuando tenga conexión a internet.");
                    alertDialog.setIcon(R.drawable.ic_connection);
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            getActivity().finish();
                        }
                    });

                    alertDialog.show();
                }

            }
        });

        if (Home.isOnline(getContext()))
            showInfoInit();
        else {

            AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();

            alertDialog.setTitle("Conexión");
            alertDialog.setMessage("No dispone de conexión a internet.\nPor favor vuelva a intentarlo cuando tenga conexión a internet.");
            alertDialog.setIcon(R.drawable.ic_connection);
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Objects.requireNonNull(getActivity()).finish();
                }
            });

            alertDialog.show();
        }


        return v;

    }


    private void showInfoInit() {

        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date d = new Date(System.currentTimeMillis());
        final String date_today = sdf.format(d);

        final MaterialDialog.Builder dialog = new MaterialDialog.Builder(Objects.requireNonNull(getContext()));
        dialog.content("Cargando datos...");
        dialog.progress(true, 150);

        final Dialog dl = dialog.show();

        final RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://api.covid19tracking.narrativa.com/api/" + date_today, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                dl.show();
                try {

                    String updated = response.getString("updated_at");
                    SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd kk:mm", Locale.forLanguageTag("es"));
                    Date d_updated = sd.parse(updated);
                    JSONObject total = response.getJSONObject("total");
                    if (d_updated != null) {
                        txt_date_updated_confirmed.setText("Actualizado el " + new SimpleDateFormat("dd/MM/yyyy kk:mm").format(d_updated));
                        txt_date_updated_death.setText("Actualizado el " + new SimpleDateFormat("dd/MM/yyyy kk:mm").format(d_updated));
                        txt_date_updated_confirmed_new.setText("Actualizado el " + new SimpleDateFormat("dd/MM/yyyy kk:mm").format(d_updated));
                        txt_date_updated_deat_new.setText("Actualizado el " + new SimpleDateFormat("dd/MM/yyyy kk:mm").format(d_updated));
                    }


                    DecimalFormat format = new DecimalFormat("###,###.##");
                    txt_number_cases_confirmed.setText(format.format(Integer.parseInt(total.getString("today_confirmed"))));
                    txt_number_cases_death.setText(format.format(Integer.parseInt(total.getString("today_deaths"))));
                    txt_number_cases_confirmed_new.setText(format.format(Integer.parseInt(total.getString("today_new_confirmed"))));
                    txt_number_death_new.setText(format.format(Integer.parseInt(total.getString("today_new_deaths"))));

                    card_confirmed.setVisibility(View.VISIBLE);
                    card_death.setVisibility(View.VISIBLE);
                    card_confirmed_new.setVisibility(View.VISIBLE);
                    card_death_new.setVisibility(View.VISIBLE);

                    dl.dismiss();
                } catch (JSONException | ParseException e) {
                    Toast.makeText(getContext(), "ERROR: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    dl.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                dl.dismiss();
            }
        });
        requestQueue.add(request);
    }

    private void showCountryInfo(final String c) {

        if (c.equalsIgnoreCase("Global"))
            showInfoInit();
        else {

            final MaterialDialog.Builder dialog = new MaterialDialog.Builder(Objects.requireNonNull(getContext()));
            dialog.content("Cargando datos...");
            dialog.progress(true, 150);

            final Dialog dl = dialog.show();

            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date d = new Date(System.currentTimeMillis());
            final String date_today = sdf.format(d);

            final RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://api.covid19tracking.narrativa.com/api/" + date_today, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    try {

                        JSONObject dates = response.getJSONObject("dates");
                        JSONObject date = dates.getJSONObject(date_today);
                        JSONObject countries = date.getJSONObject("countries");
                        JSONObject country = countries.getJSONObject(c.substring(0, c.indexOf('/')).trim());

                        DecimalFormat format = new DecimalFormat("###,###.##");
                        txt_number_cases_confirmed.setText(format.format(Integer.parseInt(country.getString("today_confirmed"))));
                        txt_number_cases_death.setText(format.format(Integer.parseInt(country.getString("today_deaths"))));
                        txt_number_cases_confirmed_new.setText(format.format(Integer.parseInt(country.getString("today_new_confirmed"))));
                        txt_number_death_new.setText(format.format(Integer.parseInt(country.getString("today_new_deaths"))));


                        dl.dismiss();
                    } catch (JSONException e) {
                        Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        dl.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    dl.dismiss();
                }
            });
            requestQueue.add(request);
        }
    }


    public ArrayList<String> getListCountries() {

        final ArrayList<String> countriesLsit = new ArrayList<>();
        countriesLsit.add("Global");

        final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date d = new Date(System.currentTimeMillis());
        final String date_today = sdf.format(d);

        final RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://api.covid19tracking.narrativa.com/api/" + date_today, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {

                    JSONObject dates = response.getJSONObject("dates");
                    JSONObject date = dates.getJSONObject(date_today);
                    JSONObject countries = date.getJSONObject("countries");
                    Iterator<String> c = countries.keys();

                    while (c.hasNext()) {
                        String key = c.next();
                        JSONObject country = countries.getJSONObject(key);
                        countriesLsit.add(key + " / " + country.getString("name_es"));
                    }


                } catch (JSONException e) {
                    Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(request);
        return countriesLsit;
    }
}
