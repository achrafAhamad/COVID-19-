package es.achraf.service;

import android.Manifest;
import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.*;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.HashMap;
import java.util.Objects;

public class ServiceLocation extends Service {

    private LocationManager manager;
    private LocationListener listener;
    Intent intent;

    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private FirebaseDatabase db = FirebaseDatabase.getInstance();

    private String uid = mAuth.getCurrentUser().getUid();
    private DatabaseReference ref = db.getReference();


    @Override
    public void onCreate() {
        super.onCreate();

        if (Build.VERSION.SDK_INT >= 26) {
            String CHANNEL_ID = "my_channel";
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "service_canal",
                    NotificationManager.IMPORTANCE_DEFAULT);

            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);

            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setContentTitle("Covid-19")
                    .setContentText("El teléfono vibrará cuando esté a menos de 2m de otro usuario.")
                    .build();
            startForeground(1, notification);
        }


    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return startCommand();


    }


    public int startCommand() {
        manager = (LocationManager) getApplication().getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

        } else {

            listener = new LocationListener() {
                @Override
                public void onLocationChanged(@NonNull final Location location) {

                    final es.achraf.model.Location loc = new es.achraf.model.Location();
                    loc.setLat(String.valueOf(location.getLatitude()));
                    loc.setLng(String.valueOf(location.getLongitude()));

                    HashMap<String, Object> map = new HashMap<>();
                    map.put(uid, loc);
                    ref.updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                checkDistance(location);
                            } else
                                Toast.makeText(getApplicationContext(), "Error: " + Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(@NonNull String provider) {

                }

                @Override
                public void onProviderDisabled(@NonNull String provider) {

                }
            };

            try {
                manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
                manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener);

            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        //si quito el on destroy no podré parar el servicio
        super.onDestroy();
        if (listener != null)
            manager.removeUpdates(listener);

    }

    private void checkDistance(final Location loc) {

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot s : snapshot.getChildren()) {
                        String id_user = s.getKey();
                        if (!uid.equalsIgnoreCase(id_user)) {

                            if (s.child("lat").getValue() != null && s.child("lng").getValue() != null) {

                                String lat = Objects.requireNonNull(s.child("lat").getValue()).toString();
                                String lng = Objects.requireNonNull(s.child("lng").getValue()).toString();

                                Location location = new Location("");
                                location.setLatitude(Double.parseDouble(lat));
                                location.setLongitude(Double.parseDouble(lng));
                                float[] results = new float[5];
                                // float distance = location.distanceTo(loc);
                                Location.distanceBetween(loc.getLatitude(), loc.getLongitude(), location.getLatitude(), location.getLongitude(), results);
                                //Toast.makeText(ServiceLocation.this, "distancia: " + results[0], Toast.LENGTH_SHORT).show();
                                if (results[0] < 2) {
                                    vibratePhone();
                                }
                            }
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(ServiceLocation.this, "Error: " + error.getDetails(), Toast.LENGTH_SHORT).show();
                }
            });

    }

    private void vibratePhone() {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        long[] pattern = {500, //sleep
                600, //vibrate
                100, 300, 100, 150, 100, 75};
        // con -1 se indica desactivar repeticion del patron
        vibrator.vibrate(pattern, -1);
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
        restartServiceIntent.setPackage(getPackageName());

        PendingIntent restartServicePendingIntent = PendingIntent.getService(getApplicationContext(), 1, restartServiceIntent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager alarmService = (AlarmManager) getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmService.set(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent);

    }
}
