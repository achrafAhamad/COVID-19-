
package es.achraf.fragments;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.SearchView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.text.HtmlCompat;
import androidx.fragment.app.Fragment;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.*;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import es.achraf.R;
import es.achraf.model.CommunityData;
import es.achraf.model.CommunityLoc;
import es.achraf.model.CountryData;
import es.achraf.utils.Utils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MapFragment extends Fragment {

    private android.widget.SearchView searchLocation;
    private GoogleMap googleMap;
    private Context context;
    private MapView mapView;
    private FusedLocationProviderClient flpc;
    private FirebaseAuth mAuht = FirebaseAuth.getInstance();
    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference ref = db.getReference();
    // private InfoCommunity infoCommunity;
    private final ArrayList<CommunityLoc> communityLocs = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.map_fragment, container, false);
        this.context = getContext();
        flpc = LocationServices.getFusedLocationProviderClient(getActivity());


        searchLocation = v.findViewById(R.id.searchLocation);
        mapView = v.findViewById(R.id.map);
        mapView.onCreate(savedInstanceState);
        mapView.onResume();


        try {
            MapsInitializer.initialize(getActivity());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap mMap) {
                googleMap = mMap;

                LocationManager locationManager =
                        (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        || ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

                    if (ActivityCompat.checkSelfPermission(context,
                            Manifest.permission.ACCESS_COARSE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {

                        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                                Manifest.permission.ACCESS_COARSE_LOCATION)) {

                        } else {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                    },
                                    Utils.ACCESS_COARSE_PERMISSION);
                        }

                    }
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                                Manifest.permission.ACCESS_FINE_LOCATION)) {

                        } else {
                            ActivityCompat.requestPermissions(getActivity(), new String[]{
                                            Manifest.permission.ACCESS_FINE_LOCATION
                                    },
                                    Utils.ACCESS_FINE_PERMISSION);
                        }
                    }

                } else {
                    if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        openDialog();
                    }
                    googleMap.setMyLocationEnabled(true);
                }
            }
        });


        //Aquí iría un progressDialog y acabaría con la finalización del bucle for
        if (context != null || googleMap != null) {
            final MaterialDialog dialog = new MaterialDialog.Builder(context)
                    .content("Cargando...")
                    .progress(true, 150)
                    .show();

            RequestQueue requestQueue = Volley.newRequestQueue(context);

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://covid19.secuoyas.io/api/v1/es/ccaa?ultimodia=true", null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    try {
                        JSONArray timeline = response.getJSONArray("timeline");
                        JSONObject data_regiones = timeline.getJSONObject(0);
                        JSONArray regiones = data_regiones.getJSONArray("regiones");

                        for (int i = 0; i < regiones.length(); i++) {


                            JSONObject region = regiones.getJSONObject(i);
                            communityLocs.add(new CommunityLoc(region.getString("nombreLugar"), region.getString("lat"), region.getString("long")));
                            JSONObject data = region.getJSONObject("data");

                            googleMap.addMarker(new MarkerOptions().position(new LatLng(Double.parseDouble(communityLocs.get(i).getLat()), Double.parseDouble(communityLocs.get(i).getLng()))));

                            CircleOptions circleOptions = new CircleOptions();
                            final LatLng latLng = new LatLng(Double.parseDouble(communityLocs.get(i).getLat()), Double.parseDouble(communityLocs.get(i).getLng()));
                            circleOptions.center(latLng);
                            circleOptions.radius(50000);
                            circleOptions.fillColor(context.getColor(R.color.orangeTransparent));
                            circleOptions.strokeColor(context.getColor(R.color.orangeTransparent));
                            circleOptions.strokeWidth(2);
                            googleMap.addCircle(circleOptions);


                        }
                        dialog.dismiss();
                        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                            @Override
                            public boolean onMarkerClick(Marker marker) {
                                searchOnMarkerMap(marker);
                                return true;
                            }
                        });

                    } catch (JSONException e) {
                        Toast.makeText(context, "ERROR: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            requestQueue.add(request);
        } else
            Toast.makeText(context, "Ha habido un problema, vuelva a intentarlo y si persiste el error, comuníquese con el administrador.", Toast.LENGTH_SHORT).show();


        flpc.getLastLocation()
                .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            double latitude = location.getLatitude();
                            double longitude = location.getLongitude();
                            LatLng latLng = new LatLng(latitude, longitude);

                            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                            googleMap.animateCamera(CameraUpdateFactory.zoomTo(8f));
                            //addCircleFromZipCode(googleMap); de momento no voy a agregar circulo en municipio sino en comunidad
                        }
                    }
                });


        searchLocation.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchLocation();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        searchLocation.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager im = ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE));
                im.showSoftInput(searchLocation, 0);
            }
        });

        return v;
    }

    private void addCircleFromZipCode(final GoogleMap googleMap, final LatLng latLng) {


        CircleOptions circleOptions = new CircleOptions();
        circleOptions.center(latLng);
        circleOptions.radius(3500);
        circleOptions.fillColor(context.getColor(R.color.greenTransaprent));
        circleOptions.strokeColor(context.getColor(R.color.greenTransaprent));
        circleOptions.strokeWidth(2);
        googleMap.addCircle(circleOptions);

    }


    public void searchLocation() {
        MaterialDialog dialog = new MaterialDialog.Builder(context)
                .content("Cargando...")
                .progress(true, 150)
                .show();
        // googleMap.clear(); //lo comento para que no me quite los circulos.
        String location = searchLocation.getQuery().toString() + ", España";
        List<Address> addressList = null;

        Geocoder geocoder = new Geocoder(getContext());

        try {
            addressList = geocoder.getFromLocationName(location, 1);

        } catch (IOException e) {
            e.printStackTrace();
        }

        if ((addressList != null ? addressList.size() : 0) != 0) {
            final Address address = addressList.get(0);

            final LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
            Toast.makeText(context, address.getLocality(), Toast.LENGTH_SHORT).show();
            // addCircleFromZipCode(googleMap,latLng);

            //googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 12));
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        } else
            Snackbar.make(getView().getRootView(), "No se ha encontrado el lugar.\nIntenta el nombre completo.", Snackbar.LENGTH_SHORT).show();

        dialog.dismiss();
    }


    private void searchOnMarkerMap(final Marker marker) {
        final MaterialDialog dialog = new MaterialDialog.Builder(context)
                .content("Buscando datos...")
                .progress(true, 150)
                .show();


        if (context != null) {
            RequestQueue requestQueue = Volley.newRequestQueue(context);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date d = new Date(System.currentTimeMillis());
            final String date_today = sdf.format(d);
            String url = "https://api.covid19tracking.narrativa.com/api/" + date_today + "/country/spain?";
            final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    try {

                        JSONObject dates = response.getJSONObject("dates");
                        JSONObject date = dates.getJSONObject(date_today);
                        JSONObject countries = date.getJSONObject("countries");
                        JSONObject spain = countries.getJSONObject("Spain");

                        //data spain general
                        String real_date = spain.getString("date");
                        String real_country = spain.getString("name_es");

                        String real_total_confirmed = spain.getString("today_confirmed");
                        String real_total_death = spain.getString("today_deaths");
                        String real_new_confirmed_today = spain.getString("today_new_confirmed");
                        String real_new_death_today = spain.getString("today_new_deaths");

                        final CountryData countryData = new CountryData(real_date, real_country, real_total_confirmed, real_total_death, real_new_confirmed_today, real_new_death_today);

                        JSONArray regions = spain.getJSONArray("regions");


                        for (int i = 0; i < regions.length(); i++) {
                            JSONObject region = (JSONObject) regions.get(i);

                            //data
                            final String name_es = region.getString("name_es");
                            String today_total_confirmed = region.getString("today_confirmed");
                            String today_total_death = region.getString("today_deaths");
                            String today_new_confirmed = region.getString("today_new_confirmed");
                            String today_new_deaths = region.getString("today_new_deaths");
                            JSONArray sub_regions = region.getJSONArray("sub_regions");
                            String source = "(fuente oficial) " + region.getString("source");

                            if (sub_regions.length() != 0) {
                                JSONObject sub_region_source = sub_regions.getJSONObject(0);
                                source = "(fuente oficial) " + sub_region_source.getString("source");
                            }


                            final CommunityData communityData = new CommunityData(name_es, today_total_confirmed, today_total_death, today_new_confirmed, today_new_deaths);

                            for (CommunityLoc cl : communityLocs) {

                                LatLng latLng = new LatLng(Double.parseDouble(cl.getLat()), Double.parseDouble(cl.getLng()));
                                if (cl.getName().equalsIgnoreCase("Comunidad Valenciana"))
                                    cl.setName(cl.getName().replace("Comunidad Valenciana", "C. Valenciana").trim());


                                if (cl.getName().equalsIgnoreCase("Pais Vasco"))
                                    cl.setName(cl.getName().replace("Pais Vasco", "País Vasco").trim());


                                if (latLng.equals(marker.getPosition()) && communityData.getName().equalsIgnoreCase(cl.getName())) {
                                    final String finalSource = source;
                                    googleMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
                                        @Override
                                        public View getInfoWindow(Marker marker) {
                                            return null;
                                        }

                                        @Override
                                        public View getInfoContents(Marker marker) {

                                            View popup = LayoutInflater.from(context).inflate(R.layout.popup_info_google, null);

                                            MaterialTextView popup_date = popup.findViewById(R.id.popup_date);
                                            MaterialTextView popup_name = popup.findViewById(R.id.popup_name);
                                            MaterialTextView popup_new_confirmated = popup.findViewById(R.id.popup_new_confirmated);
                                            MaterialTextView popup_new_death = popup.findViewById(R.id.popup_new_death);
                                            MaterialTextView popup_total_confirmated = popup.findViewById(R.id.popup_total_confirmated);
                                            MaterialTextView popup_total_death = popup.findViewById(R.id.popup_total_death);
                                            MaterialTextView popup_source = popup.findViewById(R.id.popup_source);
                                            MaterialTextView popup_link = popup.findViewById(R.id.popup_link);
                                            popup_link.setMovementMethod(LinkMovementMethod.getInstance());

                                            String html = "<a href='https://coronavirus.jhu.edu/'>https://coronavirus.jhu.edu/</a>";
                                            popup_link.setText(HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_LEGACY));

                                            popup_date.setText("Fecha de actualización: " + countryData.getDate_updated());
                                            popup_name.setText("C. Autónoma: " + communityData.getName());
                                            popup_new_confirmated.setText("Nuevos contagios: " + communityData.getNew_confirmed());
                                            popup_new_death.setText("Nuevos fallecidos: " + communityData.getNew_death());
                                            popup_total_confirmated.setText("Total contagios: " + communityData.getTotal_confirmed());
                                            popup_total_death.setText("Total fallecidos: " + communityData.getTotal_death());
                                            popup_source.setText(finalSource);


                                            dialog.dismiss();

                                            return popup;
                                        }
                                    });


                                    googleMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                                        @Override
                                        public void onInfoWindowClick(Marker marker) {
                                            String url = "https://covid19tracking.narrativa.com/";
                                            Uri uri = Uri.parse(url);
                                            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                            startActivity(intent);
                                        }
                                    });
                                    marker.showInfoWindow();

                                }
                            }
                        }

                    } catch (JSONException e) {
                        Toast.makeText(context, "ERROR: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            });
            requestQueue.add(request);
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    private void openDialog() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(30 * 1000);
        mLocationRequest.setFastestInterval(5 * 1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest);

        Task<LocationSettingsResponse> task = LocationServices.getSettingsClient(getActivity()).checkLocationSettings(builder.build());

        task.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(Task<LocationSettingsResponse> task) {
                try {
                    LocationSettingsResponse response = task.getResult(ApiException.class);

                } catch (ApiException exception) {
                    switch (exception.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:

                            try {
                                ResolvableApiException resolvable = (ResolvableApiException) exception;
                                resolvable.startResolutionForResult(getActivity(), Utils.REQUEST_CHECK_SETTINGS);
                            } catch (IntentSender.SendIntentException e) {
                                e.printStackTrace();
                            } catch (ClassCastException e) {
                                e.printStackTrace();
                            }
                            break;
                        case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                            //aquí creo que iría el código para inicializar
                            break;
                    }
                }
            }
        });
    }

}
