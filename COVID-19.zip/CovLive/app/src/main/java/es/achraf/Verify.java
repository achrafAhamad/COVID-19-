package es.achraf;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.*;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import es.achraf.model.Location;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class Verify extends AppCompatActivity {

    private TextInputEditText txt_code_sms;
    private TextInputEditText txt_zip_code;

    private MaterialButton btn_access;
    private MaterialButton btn_resent;
    private PhoneAuthProvider provider;

    private String mVerificationId;
    private String phone_back;


    private FirebaseAuth mAuth;
    private FirebaseDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify);

        this.txt_code_sms = findViewById(R.id.txt_code_sms);
        this.txt_zip_code = findViewById(R.id.txt_zip_code);

        this.btn_access = findViewById(R.id.btn_access);
        this.btn_resent = findViewById(R.id.btn_resent);
        this.mAuth = FirebaseAuth.getInstance();
        this.db = FirebaseDatabase.getInstance();
        this.provider = PhoneAuthProvider.getInstance();

        //Pantalla de verificacion del sms
        mVerificationId = getIntent().getStringExtra("verificationId");
        phone_back = getIntent().getStringExtra("phone_back");

        this.btn_access.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String codeSMS = txt_code_sms.getText().toString();
                if (TextUtils.isEmpty(txt_code_sms.getText())) {
                    Snackbar.make(getWindow().getDecorView(), "Debe ingresar el código SMS recibido.", Snackbar.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(txt_zip_code.getText())) {
                    Snackbar.make(getWindow().getDecorView(), "Debe ingresar el código postal.", Snackbar.LENGTH_SHORT).show();
                } else if (txt_zip_code.getText().length() != 5) {
                    Snackbar.make(getWindow().getDecorView(), "El código postal es incorrecto.", Snackbar.LENGTH_SHORT).show();
                } else {
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId, codeSMS);
                    signIn(credential);
                }
            }
        });
        this.btn_resent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resentCode();
            }
        });
    }

    private void signIn(final PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    saveData();
                    startActivity(new Intent(Verify.this, Home.class));
                    finish();
                } else
                    btn_resent.setVisibility(View.VISIBLE);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                btn_resent.setVisibility(View.VISIBLE);
                Toast.makeText(Verify.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void resentCode() {
        String code_spain = "+34";
        String phone = code_spain.concat(phone_back);
        if (!TextUtils.isEmpty(phone)) {

            this.provider.verifyPhoneNumber(phone, 60, TimeUnit.SECONDS, this, new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override
                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                    //signInWithCodeSMS(phoneAuthCredential);
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    if (e instanceof FirebaseAuthInvalidCredentialsException)
                        Snackbar.make(getWindow().getDecorView(), e.getMessage(), Snackbar.LENGTH_SHORT);
                    else if ((e instanceof FirebaseTooManyRequestsException))
                        Snackbar.make(getWindow().getDecorView(), "Se ha sobrepasado el limite de envío de SMS.", Snackbar.LENGTH_SHORT);
                    else
                        Toast.makeText(Verify.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    btn_resent.setVisibility(View.VISIBLE);
                }

                @Override
                public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                    super.onCodeSent(verificationId, forceResendingToken);
                    mVerificationId = verificationId;
                }
            });
        } else
            Toast.makeText(this, "Debe introducir un número de teléfono válido", Toast.LENGTH_SHORT).show();
    }


    private void saveData() {
        final String zipcode = txt_zip_code.getText().toString();
        final DatabaseReference ref = db.getReference();
        final String uid = mAuth.getCurrentUser().getUid();

        RequestQueue requestQueue = Volley.newRequestQueue(Verify.this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                "https://maps.googleapis.com/maps/api/geocode/json?address=".concat(zipcode) + ",Espa%C3%B1a&key=AIzaSyDMcPkJixVCUICePBmsDRl8kpTrXUO5Dlw",
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    Location loc = new Location();
                    JSONArray results = response.getJSONArray("results");
                    JSONObject address = results.getJSONObject(0);

                    JSONObject geometry = address.getJSONObject("geometry");
                    JSONObject location = geometry.getJSONObject("location");

                    loc.setLat(location.getString("lat"));
                    loc.setLng(location.getString("lng"));
                    loc.setZipcode(zipcode);

                    HashMap<String, Object> map = new HashMap<>();
                    map.put(uid, loc);
                    ref.updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (!task.isSuccessful())
                                Toast.makeText(Verify.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Verify.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequest);
    }
}

